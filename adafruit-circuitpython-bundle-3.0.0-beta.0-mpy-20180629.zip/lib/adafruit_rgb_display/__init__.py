"""Auto imports for Adafruit_CircuitPython_RGB_Display"""
from adafruit_rgb_display.rgb import color565
