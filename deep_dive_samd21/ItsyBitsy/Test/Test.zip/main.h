
#ifndef MAIN_H
#define MAIN_H

// <<< Use Configuration Wizard in Context Menu >>>
// <o> Delay time [milliseconds] <1-1000>
// <i> This controls how long the LED will be on
// <id> conf_delay_time
#ifndef CONF_DELAY
#define CONF_DELAY 1000
#endif
// <<< end of configuration section >>>

#endif
